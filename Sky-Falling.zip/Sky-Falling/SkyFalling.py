import turtle
import random

score = 0
level =0

# Set up the screen
wn = turtle.Screen()
wn.title("Falling Skies")
wn.bgcolor("black")
wn.setup(width=800, height=600)
wn.tracer(0)

#set up of the player
player = turtle.Turtle()
player.speed(0)
player.shape("square")
player.color("white")
player.shapesize(stretch_wid=2,stretch_len=1)
player.penup()
player.goto(0,-220)
player.direction = "stop"

#set up of the ground
ground = turtle.Turtle()
ground.speed(0)
ground.shape("square")
ground.color("gray")
ground.shapesize(stretch_wid=40,stretch_len=1)
ground.penup()
ground.goto(0,-250)
ground.left(90)

#set up of the score
pen = turtle.Turtle()
pen.speed(0)
pen.shape("square")
pen.color("white")
pen.penup()
pen.hideturtle()
pen.goto(0, 250)
pen.write("Level : 0  Score : 0 ", align="center",font=("candara", 24, "bold"))

#set up of the good shaps that will increase the score by one
good_things=[]
GoodThingsSteps = [3,4,6,7,8]
GoodThingsStep = random.choice(GoodThingsSteps)
for i in range(GoodThingsStep):
    good_thing=turtle.Turtle()
    colors = random.choice(['green', 'blue','yellow'])
    good_thing.shape("circle")
    good_thing.color(colors)
    good_thing.penup()
    good_thing.goto(0,290)
    good_thing.speed = random.randint(0, 1)
    good_things.append(good_thing) 

#set up of the bad shaps that will decrease the score by one 
bad_things=[]
BadThingsSteps = [5,6,7,8]
if score <10: extra=5
if score > 10 and score < 20: extra=10
if score > 20 and score < 30:extra=20
if score > 40 : extra=50
BadThingsStep = random.choice(BadThingsSteps)
for i in range(BadThingsStep+extra):
    bad_thing=turtle.Turtle()
    bad_thing.shape("triangle")
    bad_thing.color("red")
    bad_thing.penup()
    bad_thing.goto(100,290)
    bad_thing.speed = random.randint(0, 1)
    bad_things.append(bad_thing) 

#sensing
def GoLeft():
    if player.direction != "right":
	    player.direction = "left"

def GoRight():
	if player.direction != "left":
	    player.direction = "right"

def Move():
  
	if player.direction == "left":
		x = player.xcor()
		player.setx(x-10)
		player.direction = "stop"
        
	if player.direction == "right":
		x = player.xcor()
		player.setx(x+10)
		player.direction = "stop"

wn.listen()
wn.onkeypress(GoRight, "Right")
wn.onkeypress(GoLeft, "Left")


while True:
    wn.update()
    
    Move()
    if score < 10: 
        speed=0.5
        level=1
    if score > 10 and score < 20:
        speed=0.4
        level=2
    if score > 20 and score < 30:
        speed = 0.3
        level=3  
    if score > 30 and score < 40:
        speed = 0.2
        level=4  
    if score > 40 :
        speed = 0
        level="Max" 
     
    if player.xcor() > 390:
        player.setx(390)
    if player.xcor() < -390:
        player.setx(-390)
      
    # good things 
    for good_thing in good_things:
        
        #good things movement
        GoodThingY = good_thing.ycor()
        good_thing.sety(GoodThingY-(good_thing.speed-speed))  
             
        #good things reaching the ground
        if GoodThingY <-280:
           x = random.randint(-320,320)
           y = random.randint(50,290)
           colors = random.choice(['green', 'blue','yellow'])
           good_thing.color(colors)
           good_thing.goto(x,y)

        #good things touching the player
        if player.distance(good_thing) < 20:
           x = random.randint(-320,320)
           y = random.randint(50,290)
           colors = random.choice(['green', 'blue','yellow'])
           good_thing.color(colors)           
           good_thing.goto(x,y)
           score+=2
           pen.clear()
           pen.write("Level : {}  Score : {} ".format(level,score), align="center", font=("candara", 24, "bold"))  
                    
    #bad things
    for bad_thing in bad_things:
        
        #bad things movement
        BadThingY = bad_thing.ycor()
        bad_thing.sety(BadThingY-(bad_thing.speed-speed))

        
         #bad things reaching the ground
        if BadThingY <-280:
           x = random.randint(-320,320)
           y = random.randint(50,290)
           bad_thing.goto(x,y)

        #bad things touching the player
        if player.distance(bad_thing) < 20:
           x = random.randint(-320,320)
           y = random.randint(50,290)
           bad_thing.goto(x,y)
           score-=1
           pen.clear()
           pen.write("Level : {}  Score : {} ".format(level,score), align="center", font=("candara", 24, "bold"))  


            
        
    

        
wn.mainloop()

turtle.done()